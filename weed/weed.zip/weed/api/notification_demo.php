<?php
include(__DIR__ . "/../system/config.inc.php");

$token = "";
$text = "Hi, This is test notification";
$sendcl->ios($token, $text);

$token = "";
$msg =  array("fulltext"=>$text);
$sendcl->android($token,$msg);

