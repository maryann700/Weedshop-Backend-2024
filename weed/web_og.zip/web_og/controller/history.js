app.controller('history', function ($scope,$rootScope, $cookies,$http,$routeParams,APPKEY,API_URL,$window,$timeout) {
	var userid = $routeParams.userid;
	var data = $.param({user_id: userid,page:1});
	$scope.history = [];
	$http({
		method: "POST",
		url: API_URL + "user_order_history.php",
		async: false,
		crossDomain: true,
		headers: {
			'Content-Type': 'application/x-www-form-urlencoded',
			"APPKEY": APPKEY
		}, data
	}).then(function (response) {
		angular.forEach(response.data.data, function(item, index) {
			$scope.history.push({"products":item.products});
		});
		console.log($scope.history);
	}, function (error) {
		console.log(error);
	});
});