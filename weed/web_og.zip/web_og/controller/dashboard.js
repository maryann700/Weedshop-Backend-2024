app.controller('dashboard', function ($scope, $http,$cookies,$routeParams,APPKEY,API_URL,$window,$timeout) {
	var userid = atob($routeParams.userid);
	$(".overlay").hide();
	$scope.storeid = 0;
	$scope.CartDetail ={};
	var data = $.param({user_id: userid});
	var data = $.param({user_id: userid,action:"list"});
	$scope.count = 0;
	$http({
		method: "POST",
		url: API_URL+"cart.php",		
		headers: {'Content-Type': 'application/x-www-form-urlencoded',"APPKEY": APPKEY}, data: data,
	}).then(function (response) {
		angular.forEach(response.data.data, function(item, index) {
			$scope.CartDetail = response.data.data;
			$scope.storeid = item.store_id;
			$scope.count++;
		});
		angular.forEach($scope.total, function(item7, index) {
		});
	},
	function(err){ 
		console.log(err);
	});
	$scope.re_cart = function(){
		if($scope.count != 0){
			var cookies = {
				"userid":userid,
				"storeid":$scope.storeid
			};
			var now = new Date(),
			exp = new Date(now.getFullYear() + 1, now.getMonth(), now.getDate());
			$cookies.putObject("userdata", cookies, {expires: exp});
			$window.location.href = '/web/#!/cart/'+userid;
		}else{
			$window.location.href = 'high5://';
		}
	}
	$http({
		method: "POST",
		url: API_URL+"user_info.php",		
		headers: {'Content-Type': 'application/x-www-form-urlencoded',"APPKEY": APPKEY}, data: data,
	}).then(function (response) {
		$(".overlay").hide();
		console.log(response);
		if(response.data.response == "true"){
			$scope.name = response.data.data.name;
			$scope.dob = response.data.data.birthdate;
			$scope.mobile = response.data.data.mobile;
			$scope.email = response.data.data.email;
			$scope.address = response.data.data.address;
			$scope.identification_id = response.data.data.identification_id;
			$scope.recommendation_id = response.data.data.recommendation_id;
			$scope.image = response.data.data.image;
		}else{
			$window.location.href = 'high5://';
		}
	},
	function(err){ 
		console.log(err);
	});
});
