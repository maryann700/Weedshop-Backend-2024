app.controller('check_out', function ($scope,$rootScope, $cookies,$http,$routeParams,APPKEY,API_URL,$window,$timeout) {
	if(typeof $cookies.getObject('userdata') != 'undefined'){
		var ck = $cookies.getObject('userdata');
		if(typeof $cookies.getObject('productdata') != 'undefined'){
			var pd = $cookies.getObject('productdata');
			if(pd.count <= 0){
				$window.location.href = '/web/#!/product_detail/'+btoa(ck.userid)+'/'+btoa(ck.storeid)+'/'+btoa(ck.productid);
			}
			if(typeof $cookies.getObject('address') != 'undefined'){
				$scope.cook = $cookies.getObject('address');
			}
			$(".overlay").hide();
			$(".update_c").hide();
				//$(".add_c").hide();
				$scope.count = 0;
				$scope.count = pd.count;
				$scope.total = 0;
				$scope.total = pd.total;
				$scope.re_cart = function(){
					if($scope.count != 0){
						$window.location.href = '/web/#!/cart/'+ck.userid;
					}else{
						$window.location.href = '/web/#!/product_detail/'+btoa(ck.userid)+'/'+btoa(ck.storeid)+'/'+btoa(ck.productid);
					}
				}
				$scope.modal = function(){
					$scope.fn = "";
					$scope.ln = "";
					$scope.ad = "";
					$scope.ci = "";
					$scope.zc = "";
					$scope.re = "";
					$scope.pn = "";
					$scope.edit_lat = "";
					$scope.edit_lng = "";
					$scope.map_lat =0;
					$(".add_c").show();
					$(".update_c").hide();
					$('#myModal').modal('show');	
				}
				$scope.list = function(){
					$(".overlay").show();
					var data = $.param({user_id:ck.userid,action:"list"});
					$http({
						method: "POST",
						url: API_URL+"user_addresses.php",		
						headers: {'Content-Type': 'application/x-www-form-urlencoded',"APPKEY": APPKEY}, data: data,
					}).then(function (response) {
						$(".overlay").hide();
						$scope.Address = response.data.data;
					},
					function(err){ 
						console.log(err);
					});
				}
				var datar = $.param({type:"region"});
				$http({
					method: "POST",
					url: API_URL+"common.php",		
					headers: {'Content-Type': 'application/x-www-form-urlencoded',"APPKEY": APPKEY}, data: datar,
				}).then(function (response) {
					$scope.region = response.data.data;
				},
				function(err){ 
					console.log(err);
				});
				$scope.delete = function(id){
					var data1 = $.param({user_id:ck.userid,address_id:id,action:"delete"});
					$http({
						method: "POST",
						url: API_URL+"user_addresses.php",		
						headers: {'Content-Type': 'application/x-www-form-urlencoded',"APPKEY": APPKEY}, data: data1,
					}).then(function (response) {
						if(response.data.response == "true"){
							$scope.errormsg = "* Address successfully deleted";
							$scope.ErrorMsg = true;
							$timeout(function(){ $scope.ErrorMsg = false; },3000);
							$('html, body').animate({scrollTop: 0}, 'slow', function () {});
						}
						$scope.list();
					},
					function(err){ 
						console.log(err);
					});
				}
				$scope.add = function(a){
					$scope.map_lat = $("#lat").val();
					$scope.map_lng = $("#lng").val();
					if($scope.fn != "" && $scope.ln != "" && $scope.ad != "" && $scope.ci != "" && $scope.zc != "" && $scope.re != "" && $scope.pn !="") {
						$scope.address_zip = 0;
						$http.get("https://maps.googleapis.com/maps/api/geocode/json?latlng="+$scope.map_lat+","+$scope.map_lng+"&key=AIzaSyBHVb8KglxgjastSPBA4qZ2B3pJgPPmDus")
						.then(function (response) {
							angular.forEach(response.data.results[0].address_components, function(item, index) {
								if(item.types[0] == "administrative_area_level_1"){
									$scope.address_zip = item.short_name;
								}
							});
							if($scope.address_zip == "CA" || $scope.address_zip == "GJ" ){
								var data1 = $.param({user_id:ck.userid,firstname:$scope.fn,lastname:$scope.ln,address:$scope.ad,city:$scope.ci,zipcode:$scope.zc,region:$scope.re,state:"CA",phone:$scope.pn,latitude:$scope.map_lat,longitude:$scope.map_lng,action:"add"});
								$http({
									method: "POST",
									url: API_URL+"user_addresses.php",		
									headers: {'Content-Type': 'application/x-www-form-urlencoded',"APPKEY": APPKEY}, data: data1,
								}).then(function (response) {
									$scope.list();
									if(response.data.response == "true"){
										$('#myModal').modal('hide');
									}else{
										$scope.errormsg_add = response.data.msg;
										$scope.ErrorMsg_add = true;
										$timeout(function(){ $scope.ErrorMsg = false; },3000);
									}
								},
								function(err){ 
									console.log(err);
								});

							}else{
								alert("Please select address of california");
							}
						},
						function(err){ 
							console.log(err);
						});						
					} else {
						//alert("All field are required");
						$scope.errormsg_add = "All field are required";
						$scope.ErrorMsg_add = true;
						$timeout(function(){ $scope.ErrorMsg = false; },3000);
						return false;
					}
				}
				$scope.edit = function(a){
					$('#myModal').modal('show');
					$scope.fn = a.firstname;
					$scope.id = a.id;
					$scope.ln = a.lastname;
					$scope.ad = a.address;
					$scope.ci = a.city;
					$scope.zc = a.zipcode;
					$scope.re = a.region;
					$scope.pn = a.phone;
					$scope.edit_lat = a.latitude;
					$scope.edit_lng = a.longitude;
					$(".add_c").hide();
					$(".update_c").show();
				}
				$scope.update = function(){
					$scope.map_lat = $("#lat").val();
					$scope.map_lng = $("#lng").val();
					if($scope.fn != "" && $scope.ln != "" && $scope.ad != "" 
						&& $scope.ci != "" && $scope.zc != "" && $scope.re != "" && $scope.pn !="") {
						$scope.address_zip = 0;
					$http.get("https://maps.googleapis.com/maps/api/geocode/json?latlng="+$scope.map_lat+","+$scope.map_lng+"&key=AIzaSyBHVb8KglxgjastSPBA4qZ2B3pJgPPmDus")
					.then(function (response) {
						console.log(response);
						angular.forEach(response.data.results[0].address_components, function(item, index) {
							if(item.types[0] == "administrative_area_level_1"){
								$scope.address_zip = item.short_name;
							}
						});
						if($scope.address_zip == "CA" || $scope.address_zip == "GJ"){
							var datae = $.param({user_id:ck.userid,address_id:$scope.id,firstname:$scope.fn,lastname:$scope.ln,address:$scope.ad,city:$scope.ci,zipcode:$scope.zc,region:$scope.re,state:"CA",phone:$scope.pn,latitude:$scope.map_lat,longitude:$scope.map_lng,action:"edit"});
							$http({
								method: "POST",
								url: API_URL+"user_addresses.php",		
								headers: {'Content-Type': 'application/x-www-form-urlencoded',"APPKEY": APPKEY}, data: datae,
							}).then(function (response) {
								$(".add_c").show();
								$(".update_c").hide();
								$scope.list();
								if(response.data.response == "true"){
									$('#myModal').modal('hide');
								}else{
									$scope.errormsg_add = response.data.msg;
									$scope.ErrorMsg_add = true;
									$timeout(function(){ $scope.ErrorMsg = false; },3000);
									return false;
								}
							},
							function(err){ 
								console.log(err);
							});


						}else{
							alert("Please select address of california");
						}
					},
					function(err){ 
						console.log(err);
					});	

				} else {
					$scope.errormsg = "All field are required";
					$scope.ErrorMsg = true;
					$timeout(function(){ $scope.ErrorMsg = false; },3000);
					return false;
				}
			}
			$scope.back = function(){
				$window.location.href = '/web/#!/cart/'+ck.userid;
			}
			$scope.next = function(){
				$(".overlay").show();
				$timeout(function(){
					$(".overlay").hide();
				},1500);
				if(typeof $cookies.getObject('address') != 'undefined'){
					$cookies.remove("address");
				}
				$rootScope.add = $(".delivary_add").find(".theone").attr("id");
				var get_nm = $(".delivary_add").find(".theone").parents(".part").find(".get_nm").text();
				var get_pn = $(".delivary_add").find(".theone").parents(".part").find(".get_pn").text();
				var get_add = $(".delivary_add").find(".theone").parents(".part").find(".get_add").text();
				var get_lat = $(".delivary_add").find(".theone").parents(".part").find(".get_lat").val();
				var get_lng = $(".delivary_add").find(".theone").parents(".part").find(".get_lng").val();
				if($rootScope.add != '' && $rootScope.add != null){
					var cookies = {
						"id":$rootScope.add,
						"nm":get_nm,
						"pn":get_pn,
						"add":get_add,
						"lat":get_lat,
						"lng":get_lng
					};
					var now = new Date(),
					exp = new Date(now.getFullYear() + 1, now.getMonth(), now.getDate());
					$cookies.putObject("address", cookies, {expires: exp});
					$window.location.href = '/web/#!/order-confirmation';	
				}else{
					$scope.errormsg = "Please select address";
					$scope.ErrorMsg = true;
					$timeout(function(){ $scope.ErrorMsg = false; },3000);
					$('html, body').animate({scrollTop: 0}, 'slow', function () {});
				}
			}
		}else{
			$window.location.href = '/web/#!/cart/'+ck.userid;
		}
	}else{
		$window.location.href = 'high5://';
	}
});