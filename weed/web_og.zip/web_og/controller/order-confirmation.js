app.controller('order-confirmation', function ($scope,$rootScope, $cookies,$http,$routeParams,APPKEY,API_URL,$window,$timeout) {
	//if($rootScope.add !='' && $rootScope.add != null){
		if(typeof $cookies.getObject('userdata') == 'undefined'){
			return false;
		}
		if(typeof $cookies.getObject('address') != 'undefined'){
			$(".overlay").hide();
			$(".overlay").show();
			var ck = $cookies.getObject('userdata');
			$scope.ad = $cookies.getObject('address');
			// console.log($scope.ad);
			var data = $.param({user_id:ck.userid,action:"list"});
			$scope.count = 0;
			$scope.total = [];
			$scope.sub_total = 0;
			$scope.all_product = [];
			$scope.store_lat = 0;
			$scope.store_lng = 0;
			$scope.get_destance = [];
			$scope.delivery_charge = 0;
			$scope.approve = true;
			$scope.cart_total_count = 0;
			var pd = $cookies.getObject('productdata');
			$scope.cart_total_count = pd.count;
			if($scope.cart_total_count == 0){
				$window.location.href = '/web/#!/cart/'+ck.userid;
			}
			$scope.re_cart = function(){
				if($scope.cart_total_count != 0){
					$window.location.href = '/web/#!/cart/'+ck.userid;
				}else{
					$window.location.href = '/web/#!/product_detail/'+btoa(ck.userid)+'/'+btoa(ck.storeid)+'/'+btoa(ck.productid);
				}
			}
			$http({
				method: "POST",
				url: API_URL+"cart.php",		
				headers: {'Content-Type': 'application/x-www-form-urlencoded',"APPKEY": APPKEY}, data: data,
			}).then(function (response) {
			//console.log(response);
			if(typeof response.data.data[0] == 'undefined'){
				$window.location.href = '/web/#!/cart/'+ck.userid;
			}else{
				$scope.store_lat = response.data.data[0].latitude;
				$scope.store_lng = response.data.data[0].longitude;
			}
			angular.forEach(response.data.data, function(item, index) {
				$scope.CartDetail = response.data.data;
				$scope.total.push({"id":item.product_id,"price":parseInt(item.price),"cart_quantity":item.cart_quantity});
				$scope.count++;
				angular.forEach(item.attributes, function(item7, index) {
					$scope.all_product.push({"product_id":item.product_id,"quantity":item.cart_quantity,"price":item.price,"product_name":item.name,"type":item.type_id,"attribute_description":item7.attribute_text +" || "+ item7.name});
				});
			});
			angular.forEach($scope.total, function(item7, index) {
				$scope.sub_total = $scope.sub_total+item7.price*item7.cart_quantity;
			});
		},
		function(err){ 
			console.log(err);
		});
			$http({
				method: "POST",
				url: API_URL+"delivery_charges.php",
				headers: {'Content-Type': 'application/x-www-form-urlencoded',"APPKEY": APPKEY},
			}).then(function (response) {
				$scope.charge = response.data.data;
			//console.log($scope.charge);
		},
		function(err){ 
			console.log(err);
		});
			$timeout(function(){ 
				var lat1 = $scope.store_lat;
				var lon1 = $scope.store_lng;
				var lat2 = $scope.ad.lat;
				var lon2 = $scope.ad.lng;
				console.log(lat1+ +lon1+ +lat2+ +lon2);
				if($scope.store_lat ==0 ||  $scope.store_lng ==0){
					$scope.errormsg = "* Please reload this page.";
					$scope.ErrorMsg = true;
					$timeout(function(){ $scope.ErrorMsg = false; },3000);
					$('html, body').animate({scrollTop: 0}, 'slow', function () {});
					$scope.approve = false;
				}
			var R = 6371; // Radius of the earth in km
		  	var dLat = deg2rad(lat2-lat1);  // deg2rad below
		  	var dLon = deg2rad(lon2-lon1); 
		  	var a = 
		  	Math.sin(dLat/2) * Math.sin(dLat/2) +
		  	Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2)) * 
		  	Math.sin(dLon/2) * Math.sin(dLon/2)
		  	; 
		  	var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a)); 
		  $scope.d = parseInt(R * c); // Distance in km
		  // console.log($scope.d);

		  function deg2rad(deg) {		  	
		  	$(".overlay").hide();
		  	return deg * (Math.PI/180)
		  }
		},1500);
			$timeout(function(){ 
				angular.forEach($scope.charge, function(item, index) {
					$scope.get_destance.push({"min":item.min_distance,"max":item.max_distance,"price":item.price});
				});
				console.log($scope.get_destance);
				for(var i=0;i<$scope.get_destance.length;i++){
					if($scope.d>=parseInt($scope.get_destance[i].min) && $scope.d<parseInt($scope.get_destance[i].max)){
						$scope.delivery_charge = $scope.get_destance[i].price;
						break;
					}else{
						$scope.delivery_charge = 10;
					}
				}
				$scope.main_total = $scope.sub_total + $scope.delivery_charge;
			},1800);

		//console.log($scope.ad);
		$scope.order = function(){
			$(".overlay").show();
			if($scope.approve == true){
				var json_data = JSON.stringify($scope.all_product);
				var order = $.param({user_id:ck.userid,store_id:ck.storeid,address:$scope.ad.id,product:json_data,delivery_charge:$scope.delivery_charge});
				$http({
					method: "POST",
					url: API_URL+"order.php",
					headers: {'Content-Type': 'application/x-www-form-urlencoded',"APPKEY": APPKEY}, data: order,
				}).then(function (response) {
					$(".overlay").hide();
					if(response.data.response == "true"){
						$cookies.remove("userdata");
						$cookies.remove("address");
						$cookies.remove("productdata");
						$window.location.href = 'high5://';
					}else{
						$scope.errormsg = response.data.msg;
						$scope.ErrorMsg = true;
						$timeout(function(){ $scope.ErrorMsg = false; },2400);
						$('html, body').animate({scrollTop: 0}, 'slow', function () {});
					}
				//	console.log(response);
			},
			function(err){ 
				console.log(err);
			});
			}else{
				$scope.errormsg = "* Please reload this page.";
				$scope.ErrorMsg = true;
				$timeout(function(){ $scope.ErrorMsg = false; },3000);
				$('html, body').animate({scrollTop: 0}, 'slow', function () {});
			}
		}
	}else{
		$window.location.href = '/web/#!/check_out';
	}
});