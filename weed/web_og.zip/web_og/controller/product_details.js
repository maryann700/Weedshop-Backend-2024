app.controller('product_details', function ($scope, $http,$cookies,$rootScope,$routeParams,APPKEY,API_URL,$window,$timeout) {
	$(".overlay").hide();
	var userid = atob($routeParams.userid);
	var storeid = atob($routeParams.storeid);
	var productid = atob($routeParams.productid);
	// var decodedString = atob('MTc=');
	// var decodedString2 = atob('MQ==');
	// var decodedString3 = atob('Mjk=');
	// console.log(userid);
	// console.log(storeid);
	// console.log(productid);
	if(typeof $cookies.getObject('productdata') != 'undefined'){
		$cookies.remove("productdata");
	}
	$(".overlay").show();
	var data1 = $.param({user_id: userid});
	$http({
		method: "POST",
		url: API_URL+"user_info.php",		
		headers: {'Content-Type': 'application/x-www-form-urlencoded',"APPKEY": APPKEY}, data: data1,
	}).then(function (response) {
		$(".overlay").hide();
		if(response.data.response == "true"){
			var data = $.param({user_id: userid,action:"list"});
			$scope.count = 0;
			$http({
				method: "POST",
				url: API_URL+"cart.php",		
				headers: {'Content-Type': 'application/x-www-form-urlencoded',"APPKEY": APPKEY}, data: data,
			}).then(function (response) {
				angular.forEach(response.data.data, function(item, index) {
					$scope.CartDetail = response.data.data;
					$scope.count++;
				});
				angular.forEach($scope.total, function(item7, index) {
				});
			},
			function(err){ 
				console.log(err);
			});
				//$scope.myInterval = 1000;	
				//$rootScope.productid =  $routeParams.productid;
				$scope.re_cart = function(){
					// $(".overlay").show();
					// $timeout(function(){
					// 	$(".overlay").hide();
					// },1500);
					if($scope.count != 0){
						$window.location.href = '/web/#!/cart/'+userid;
					}else{
						$scope.errormsg = "* First you need to add product in cart.";
						$scope.ErrorMsg = true;
						$timeout(function(){ $scope.ErrorMsg = false; },3000);
					}
				}
				if(typeof $cookies.getObject('userdata') != 'undefined'){
					$cookies.remove("userdata");
				}
				var cookies = {
					"userid":userid,
					"storeid":storeid,
					"productid":productid
				};
				var now = new Date(),
				exp = new Date(now.getFullYear() + 1, now.getMonth(), now.getDate());
				$cookies.putObject("userdata", cookies, {expires: exp});
				$scope.ProductDetail ={};
				$scope.ttt = 1;
				$scope.slider = [];
				$scope.attributes = [];
				var data = $.param({store_id: storeid,product_id:productid});
				$http({
					method: "POST",
					url: API_URL+"product_detail.php",		
					headers: {'Content-Type': 'application/x-www-form-urlencoded',"APPKEY": APPKEY}, data: data,
				}).then(function (response) {
					if(response.data.response == "false"){
						$scope.errormsg = response.data.msg;
						$scope.ErrorMsg = true;
						return false;
					}
					$scope.ProductDetail = response.data.data;
					angular.forEach($scope.ProductDetail, function(item, index) {
						$scope.detail = item.description;
						$scope.name = item.name;
						$scope.color = item.color;
						$scope.quantity = item.quantity;
						$scope.type = item.type;
						$scope.slider.push({"image_name":item.image,"image_path":item.main_image_url,"type":"main"});
						angular.forEach(item.images, function(item2, index2) {
							$scope.slider.push({"image_name":item2.image,"image_path":item2.image_url,"type":"comman"});
						});
						$scope.attributes_loop =item.attributes; 
					});
					angular.forEach($scope.attributes_loop, function(item1, index1) {
						$scope.attributes.push({"attribute_text":item1.attribute_text , "name":item1.name});
					//$scope.attributes = item1;
					//$scope.attributes = item1.attribute_text +" "+item1.name;
				});
				},
				function(err){ 
					console.log(err);
				});
				$scope.add_cart = function(){
					$(".overlay").show();
					var MyDiv1 = document.getElementById('output');
					$scope.qty = MyDiv1.innerHTML;
					if(typeof $scope.qty == "undefined" || $scope.qty == "" || $scope.qty == 0 ) {
						$scope.errormsg = "* Please make sure that quantity is greater then 0";
						$scope.ErrorMsg = true;
						$timeout(function(){ $scope.ErrorMsg = false; },3000);
						$('html, body').animate({scrollTop: 0}, 'slow', function () {});
						return false;
					}else{
						var data = $.param({user_id: userid,store_id: storeid,quantity:$scope.qty,product_id:productid,action:"add"});
						$http({
							method: "POST",
							url: API_URL + "cart.php",
							async: false,
							crossDomain: true,
							headers: {
								'Content-Type': 'application/x-www-form-urlencoded',
								"APPKEY": APPKEY
							}, data
						}).then(function (response) {
							$(".overlay").hide();
							if (response.status == 200 && response.data.response == "true") {
								$window.location.href = '/web/#!/cart/'+userid;
							}else{
								$scope.errormsg = response.data.msg;
								$scope.ErrorMsg = true;
								$timeout(function(){ $scope.ErrorMsg = false; },3000);
								$('html, body').animate({scrollTop: 0}, 'slow', function () {});
							}
						}, function (error) {
							console.log(error);
						});
					}
				}
			}else{
				$scope.errormsg = response.data.msg;
				$scope.ErrorMsg = true;
				return false;
		//$timeout(function(){ $scope.ErrorMsg = false; },3000);
	}
},
function(err){ 
	console.log(err);
});
});