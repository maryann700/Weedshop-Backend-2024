app.controller('cart', function ($scope,$rootScope, $cookies,$http,$routeParams,APPKEY,API_URL,$window,$timeout) {
//	$("#loading_loader").hide();
$(".overlay").hide();
var userid = $routeParams.userid;
$scope.CartDetail ={};
$scope.ttt = 10;
$scope.count = 0;
$scope.total = [];
$scope.sub_total = 0;
$scope.this_product = 0;
if(typeof $cookies.getObject('userdata') != 'undefined'){
	var ck = $cookies.getObject('userdata');
	if(ck.userid == userid){
		$scope.list = function(){
			$(".overlay").show();
			var data = $.param({user_id: userid,action:"list"});
			$http({
				method: "POST",
				url: API_URL+"cart.php",		
				headers: {'Content-Type': 'application/x-www-form-urlencoded',"APPKEY": APPKEY}, data: data,
			}).then(function (response) {
				$(".overlay").hide();
				if(response.data.data.length == 0){
					$window.location.href = '/web/#!/product_detail/'+btoa(ck.userid)+'/'+btoa(ck.storeid)+'/'+btoa(ck.productid);
				}
				angular.forEach(response.data.data, function(item, index) {
					$scope.CartDetail = response.data.data;
					$scope.total.push({"id":item.product_id,"price":parseInt(item.price),"cart_quantity":item.cart_quantity});
					$scope.count++;
				});
				angular.forEach($scope.total, function(item7, index) {
					$scope.sub_total = $scope.sub_total+item7.price*item7.cart_quantity;
				});
			},
			function(err){ 
				console.log(err);
			});
		}
		//Comment This Code Start
		$scope.get_sub_total = function(){
			return '1000';
		};
		//Comment This Code  End

		$scope.$watch('sub_total', function(newValue, oldValue) {
			var someVar = ["Demo"];
			$('.update_sub_total').html(newValue);

	    // angular copy will preserve the reference of $scope.someVar
	    // so it will not trigger another digest 
	    angular.copy(someVar, $scope.someVar);

	});

	//Remove Product From Cart
	$scope.remove_cart = function(productdetail){
		// $(".dvLoading").addClass('overlay');
		// $("#loading_loader").show();
		$(".overlay").show();
		$timeout(function(){
			$(".overlay").hide();
			// $(".dvLoading").removeClass('overlay');
			// $("#loading_loader").hide();
		},1500);
		if($scope.sub_total <0){
			$window.location.href = '/web/#!/cart/'+ck.userid
		}
		var data = $.param({user_id: userid,product_id:productdetail.product_id,action:"delete"});
		$http({
			method: "POST",
			url: API_URL+"cart.php",		
			headers: {'Content-Type': 'application/x-www-form-urlencoded',"APPKEY": APPKEY}, data: data,
		}).then(function (response) {
			if(response.data.response == "true"){
				$("#"+productdetail.product_id).slideUp(500);
				var quan = $('#'+productdetail.product_id).find('#output').attr('title');
				$scope.this_product = productdetail.price*quan;
				$scope.sub_total = $scope.sub_total-(productdetail.price*quan);
				$scope.count--;
				$scope.errormsg = "* Product successfully deleted";
				$scope.ErrorMsg = true;
				$timeout(function(){ $scope.ErrorMsg = false; },3000);
				$('html, body').animate({scrollTop: 0}, 'slow', function () {});
				if($scope.count == 0){
					if(typeof $cookies.getObject('productdata') != 'undefined'){
						$cookies.remove("productdata");
					}
					$window.location.href = '/web/#!/product_detail/'+btoa(ck.userid)+'/'+btoa(ck.storeid)+'/'+btoa(ck.productid);
					//$window.location.href = '/web/#!/product_detail/'+ck.userid+'/'+ck.storeid+'/'+ck.productid;
				}
			}
		},
		function(err){ 
			console.log(err);
		});
	}
	//Update Product From Cart
	$scope.update_cart = function(){
		$(".overlay").show();
		$timeout(function(){
			$(".overlay").hide();
		},1500);
		//Check User Status Start user_info.php
		var data1 = $.param({user_id: ck.userid});
		$http({
			method: "POST",
			url: API_URL+"user_info.php",		
			headers: {'Content-Type': 'application/x-www-form-urlencoded',"APPKEY": APPKEY}, data: data1,
		}).then(function (response) {
			var userdetail = response.data.data;
			$scope.status = "";
			$scope.reason = "";
			$scope.msg = "";
			$scope.link = "";
			$scope.btn = false;
			$rootScope.next = false;
			if(userdetail.adminApproved == "Approved"){
				var qua = $(".output").map(function() {
					return $(this).attr('title');
				});
				var id = $(".output").map(function() {
					return $(this).attr('alt');
				});
				$scope.product =[];
				for (var i=0; i<id.length; i++){
					$scope.product.push({"product_id":id[i],"quantity":qua[i]});
				}
				var productss = JSON.stringify($scope.product);
				var data = $.param({user_id: userid,store_id: ck.storeid,product:productss,action:"update"});
				$http({
					method: "POST",
					url: API_URL+"cart.php",		
					headers: {'Content-Type': 'application/x-www-form-urlencoded',"APPKEY": APPKEY}, data: data,
				}).then(function (response) {
					$scope.sub_total = 0;
					$scope.total = [];
					angular.forEach(response.data.data, function(item, index) {
						$scope.CartDetail = {};
						$scope.CartDetail = response.data.data;
						$scope.total.push({"id":item.product_id,"price":parseInt(item.price),"cart_quantity":item.cart_quantity});
					});	
					angular.forEach($scope.total, function(item7, index) {
						$scope.sub_total = $scope.sub_total+item7.price*item7.cart_quantity;
					});
					var cookies = {
						"count":$scope.count,
						"total":$scope.sub_total,
					};
					$rootScope.next = true;
					var now = new Date(),
					exp = new Date(now.getFullYear() + 1, now.getMonth(), now.getDate());
					$cookies.putObject("productdata", cookies, {expires: exp});
					$window.location.href = '/web/#!/check_out';
				},
				function(err){ 
					console.log(err);
				});
			}else if(userdetail.adminApproved == "Pending"){
				$('#myModal').modal('show');
				$scope.status = "Pending";
				$scope.reason = userdetail.adminRejectReason;
				$scope.msg = userdetail.verifymsg;
			}else if(userdetail.adminApproved == "Rejected"){
				$('#myModal').modal('show');
				$scope.status = "Rejected";
				$scope.reason = userdetail.adminRejectReason;
				$scope.msg = userdetail.verifymsg;
				$scope.btn = true;
				if(userdetail.adminRejectReason == "Identification|Recommendation" || userdetail.adminRejectReason == "Identification,Recommendation"){
					$scope.link = "high5identification-recommendation://";
				}else if(userdetail.adminRejectReason == "Identification"){
					$scope.link = "high5identification://";
				}else if(userdetail.adminRejectReason == "Recommendation"){
					$scope.link = "high5recommendation://";
				}
			}
		},
		function(err){ 
			console.log(err);
		});
		//Check User Status End
	}
	$scope.update_product = function(c){
		var quan = $('#'+c.product_id).find('#output').attr('title');
		var data = $.param({user_id: userid,store_id: ck.storeid,product_id:c.product_id,quantity:quan,action:"update_product"});
		$http({
			method: "POST",
			url: API_URL+"cart.php",		
			headers: {'Content-Type': 'application/x-www-form-urlencoded',"APPKEY": APPKEY}, data: data,
		}).then(function (response) {
			$scope.sub_total = 0;
			$scope.total = [];
			angular.forEach(response.data.data, function(item, index) {
				$scope.total.push({"id":item.product_id,"price":parseInt(item.price),"cart_quantity":item.cart_quantity});
			});	
			angular.forEach($scope.total, function(item7, index) {
				$scope.sub_total = parseInt($scope.sub_total+item7.price*item7.cart_quantity);
			});
			var cookies = {
				"count":$scope.count,
				//"total":$scope.sub_total,
			};
			var now = new Date(),
			exp = new Date(now.getFullYear() + 1, now.getMonth(), now.getDate());
			$cookies.putObject("productdata", cookies, {expires: exp});
		},
		function(err){ 
			console.log(err);
		});
	}
}else{
	$window.location.href = 'high5://';
}
}else{
	$window.location.href = 'high5://';	
}
});