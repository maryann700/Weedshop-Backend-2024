  var app = angular.module("myApp", ["ngCookies","ngRoute","ui.bootstrap"]);
  // app.run(function ($rootScope, $location,  $route, API_URL, $http) {
  //   $rootScope.userid = $routeParams.userid;
  //   $rootScope.storeid = $routeParams.storeid;
  //   $rootScope.productid = $routeParams.productid;
  // });
  app.constant({
  	APPKEY: '582e7d442740f326cc32a5ade9ed92f1',
  	API_URL: 'http://high5delivery.com/weed/api/'
  });
  app.config(function ($interpolateProvider, $httpProvider)
  {
  	$interpolateProvider.startSymbol('<<');
  	$interpolateProvider.endSymbol('>>');

  });
  app.run(function ($rootScope, $cookies, $location, $filter, $route, API_URL, $http) {
  });
  app.config( [
    '$compileProvider',
    function( $compileProvider )
    {   
      $compileProvider.aHrefSanitizationWhitelist(/^\s*(https?|ftp|mailto|chrome-extension):/);
        // Angular before v1.2 uses $compileProvider.urlSanitizationWhitelist(...)
      }
      ]);
  app.config(function ($routeProvider) {
  	$routeProvider
  	.when("/product_detail/:userid/:storeid/:productid", {
  		templateUrl: "view/product_details.html",
        //controller: 'cart',
      })
  	.when("/cart/:userid", {
  		templateUrl: "view/cart.html",
  	})
  	.when("/check_out", {
  		templateUrl: "view/check_out.html",
  	})
  	.when("/order-confirmation", {
  		templateUrl: "view/order-confirmation.html",
  	})
  	.when("/dashboard/:userid", {
  		templateUrl: "view/dashboard.html",
  	})
  	.when("/history/:userid", {
  		templateUrl: "view/history.html",
  	})
  	;
  });