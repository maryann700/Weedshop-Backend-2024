$('#banner').owlCarousel({
    loop: true,
    margin: 0,
    nav: true,
    mouseDrag:true,
    autoplay:true,
    
    //autoplayTimeout:true,
    //autoHeight:true,
    
    //animateOut: 'slideOutDown',
    //animateIn: 'flipInX',
    animateOut: 'fadeOut',
    animateIn: 'fadeIn',
    
    //smartSpeed:10000,
    //autoplaySpeed:10000,
    responsive: {
        0: {
            items: 1
        },
        600: {
            items: 1
        },
        1000: {
            items: 1
        }
    }
});
$(document).ready(function() {

 $("input:radio").on("click",function (e) {
    var inp=$(this);
    if (inp.is(".theone")) {
        inp.prop("checked",false).removeClass("theone");
    } else {
        $("input:radio[name='"+inp.prop("name")+"'].theone").removeClass("theone");
        inp.addClass("theone");
    }

});


});